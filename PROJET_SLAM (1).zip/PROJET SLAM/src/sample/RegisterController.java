package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.sql.Connection;
import java.sql.Statement;


public class RegisterController {
        @FXML
        private Button RegisterButton;

        @FXML
        private TextField usernameTextField;

        @FXML
        private Button closeButton;

        @FXML
        private PasswordField setPasswordField;

        @FXML
        private PasswordField confirmPasswordField;

        @FXML
        private TextField lastnameTextField;

        @FXML
        private TextField firstnameTextField;

        @FXML
        private ComboBox<?> type_up;

        @FXML
        private Label registrationMessageLabel;

        @FXML
        private Label confirmPasswordLabel;



        public void closeButtonOnAction(ActionEvent event) {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
        Platform.exit();
        }

        public void registerButtonAction(ActionEvent event){

                if(setPasswordField.getText().equals(confirmPasswordField.getText())) {
                        registerUser();
                        confirmPasswordLabel.setText("");
                } else {
                        confirmPasswordLabel.setText("Les mots de passe ne correspondent pas");
                }
        }

        public void registerUser() {
                DatabaseConnection connectNow = new DatabaseConnection();
                Connection connectDB = connectNow.getConnection();

                String firstname = firstnameTextField.getText();
                String lastname = lastnameTextField.getText();
                String username = usernameTextField.getText();
                String password = setPasswordField.getText();

                String insertFields = "INSERT INTO user_account(lastname, firstname, username, password) VALUES ('";
                String insertValue = firstname + "','" + lastname + "','" + username + "','" + password + "')";
                String insertToRegister = insertFields + insertValue;

                try {
                        Statement statement = connectDB.createStatement();
                        statement.executeUpdate(insertToRegister);
                        registrationMessageLabel.setText("L'utilisateur a été enregistré correctement !");
                } catch (Exception e) {
                        e.printStackTrace();
                        e.getCause();
                }
        }
}

