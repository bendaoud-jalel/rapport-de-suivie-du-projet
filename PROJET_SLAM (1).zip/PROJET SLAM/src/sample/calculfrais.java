package fr.deruche;

//import java.sql.Connection;
import java.time.LocalDate;
import java.util.Scanner;

public class FicheFrais {
    LocalDate fdrm_receptionfrais;
    LocalDate fdrm_validationfrais;
    LocalDate fdrm_paiementfrais;
    LocalDate fhhdrm_remboursementfrais;
    int nbrj_conges;
    int fr_quantiteForfaitaire;
    double fr_montant;
    double fr_fraisForfaitaire;
    LocalDate fr_dateFrais;
    int Saisirfrais;
    double MFR_montant_unitaire_nuit;
    int MFR_quantite_nuit;
    double MFR_montant_unitaire_repas_midi;
    int MFR_quantite_repas_midi;
    int quantite_kilometre;
    double prix_kilometre;
    double fr_totalForfaitaire;
    double fr_totalAutreFrais;
    double montantAutreFrais;
    String Libelle;
    double TotalNuite;
    double fraisNuit;
    double fraisRepas;
    double TotalRepas;
    double TotalKilometre;
    double fraisKimoletre;

    public void calculernuite(){

    }

    public FicheFrais() {
        afficherfraisforfaitaire();
        calculernuite();
    }

    public void afficherfraisforfaitaire() {
        Scanner scanner= new Scanner(System.in);
        //System.out.print("Veuillez entrer le prix unitaire des nuités");
        //double frais = scanner.nextDouble();
        System.out.println("Veuillez entrer la quantité de nuité");
        int quantitenuit = scanner.nextInt();
        TotalNuite = fraisNuit * quantitenuit;
        fr_dateFrais = LocalDate.now();
        System.out.println(TotalNuite + "  " + fr_dateFrais.toString());

        System.out.println("Veuillez entrer la quantité Repas midi");
        int quantiterepas = scanner.nextInt();
        TotalRepas = fraisRepas * quantiterepas;
        fr_dateFrais = LocalDate.now();
        System.out.println(TotalRepas + "  " + fr_dateFrais.toString());

        System.out.println("Veuillez entrer le nombre de kilomètre");
        int quantite_kilometre = scanner.nextInt();
        TotalKilometre = quantite_kilometre * fraisKimoletre;
        System.out.println(TotalKilometre);
        scanner.nextLine();
        //System.out.println("Veuillez entrer la quantite ");
        //String Libelle = scanner.nextLine();
        //System.out.println("Voici votre libelle : " + "  " + Libelle);
        //System.out.println("Voici vos frais : " + frais + "  " + fr_dateFrais + "  " + Libelle);
    }
}