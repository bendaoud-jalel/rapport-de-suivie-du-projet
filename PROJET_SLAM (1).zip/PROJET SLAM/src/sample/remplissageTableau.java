public class frais {

    String frais_forfaitaire;
    double quantite;
    double montant_unitaire;
    double total;

    public frais(String frais_forfaitaire, double quantite, double montant_unitaire, double total) {
        this.frais_forfaitaire = frais_forfaitaire;
        this.quantite = quantite;
        this.montant_unitaire = montant_unitaire;
        this.total = total;
    }

    public String getFrais_forfaitaire() {

        return frais_forfaitaire;
    }

    public double getQuantite() {

        return quantite;
    }

    public double getMontant_unitaire() {
        return montant_unitaire;
    }

    public double getTotal() {

        return total;
    }

    public void setFrais_forfaitaire(String frais_forfaitaire) {

        this.frais_forfaitaire = frais_forfaitaire;
    }

    public void setQuantite(int quantite) {

        this.quantite = quantite;
    }

    public void setMontant_unitaire(int montant_unitaire) {

        this.montant_unitaire = montant_unitaire;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}