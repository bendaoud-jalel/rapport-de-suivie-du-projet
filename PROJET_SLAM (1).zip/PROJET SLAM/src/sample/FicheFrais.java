package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class Tableview<F> implements Initializable{
    @FXML
    private Tableview<frais> tableau;
    @FXML
    private TableColumn<frais, String> frais_forfaitaires;
    @FXML
    private TableColumn<frais, Integer> quantite;
    @FXML
    private TableColumn<frais, Integer> montant_unitaire;
    @FXML
    private TableColumn<frais, Integer> total;

    public ObservableList<frais> list = FXCollections.observableArrayList(
            new frais("Nuitée", 2.00, 80.00, 2.00),
            new frais("Repas Midi", 5.00, 29.00, 2.00),
            new frais("Kilométrage", 2.00, 50.45, 2.00)
    );
    @Override
    public void initialize(URL url, ResourceBundle rb){
        frais_forfaitaires.setCellValueFactory(new PropertyValueFactory<frais, String>("frais_forfaitaire"));
        quantite.setCellValueFactory(new PropertyValueFactory<frais, Integer>("quantite"));
        montant_unitaire.setCellValueFactory(new PropertyValueFactory<frais, Integer>("montant_unitaire"));
        total.setCellValueFactory(new PropertyValueFactory<frais, Integer>("total"));

        tableau.setItem(list);
    }

}